<?
#find a patrol vehicle
?>
<html>
<head>
<title>Find a Patrol</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<link rel="stylesheet" type="text/css" href="./extjs4.7/resources/css/ext-all.css" />
<style type="text/css">
body {
    margin: 0;
    /*margin-bottom: 3em;*/
    padding: 0;
    font-family: Calibri,Verdana, sans-serif;
	font-size: 11px;
    background-color: #fff;
    color: #000;
    overflow: hidden;
}
div#hd1 {
    text-align: left;
    border-bottom: 2px solid black;
    position:absolute;
    bottom:0;
    right:0;
    width:200px;
    height: 200px;
    background:#000;
    z-index:1000;
    filter:alpha(opacity=60);-moz-opacity:0.6;-khtml-opacity:0.6;opacity:0.6;
    color:#fff;
}
div#hd {
    text-align: left;
    border-bottom: 2px solid black;
    position:absolute;
	padding-left:5px;
    bottom:0;
    left:0;
    bottom:0;
    width:100%;
    height: 160px;
    background:#000;
    z-index:1000;filter:alpha(opacity=80);-moz-opacity:0.8;-khtml-opacity:0.8;opacity:0.8;
    color:#fff;
}

div#complaintsDiv {
    text-align: left;
    border-bottom: 2px solid black;
	border-right: 2px solid black;
    position:absolute;
    top:20%;
    left:20%;
    width:800px;
    height: 500px;
	/*overflow-y:auto;
	overflow-x:hidden;*/
    background:#a1bcdf;
    z-index:1000;filter:alpha(opacity=99);-moz-opacity:0.99;-khtml-opacity:0.99;opacity:0.99;
    color:#000;
    font-family: Calibri,Verdana,Tahoma,arial;
    font-size: 11px;	
}

div#complaintsList {
    /*text-align: left;width:800px;background:#a1bcdf;color:#000;font-family: Calibri,Verdana,Tahoma,arial;font-size: 10px;			*/
}

div#hd h1 {
    margin-bottom: 0;
    font-size: 1.5em;
    color:#FF0000;
}
p{
    font-weight: bold;
    margin-bottom: 0;
    font-size: 1.5em;
    color:#fff;
    font-family: Verdana,Tahoma,arial;
    font-size: 11px;
}
input#BtnSave,#BtnReset,#ButtonFind{
    font-family: Verdana,Tahoma,arial;
    font-size: 11px;
	width:100px;
	height:25px;
	padding:5 5 5 5;
}
input#BtnSave,#BtnShow{
    font-family: Verdana,Tahoma,arial;
    font-size: 11px;
	width:120px;
	height:25px;
	padding:5 5 5 5;	
}
input#geocodeInput{
    font-family: Verdana,Tahoma,arial;
    font-size: 11px;
	width:250px;
	height:20px;		
}
input#name,#mobile,#address,#phone{
    font-family: Verdana,Tahoma,arial;
    font-size: 11pt;
}
input#BtnReset{
    color:#FF0000;
}
.contactInfo{
    font-weight: bold;
    margin-bottom: 0;
    font-size: 1.5em;
    color:#fff;
    font-family: Verdana,tahoma,arial;
    font-size: 11px;
}
.contactInfoHeading{
    margin-bottom: 0;
    font-size: 1.5em;
    color:#f00;
}
#lat, #lon, #timezone, #latlon1, #latlon2{
    margin-bottom: 0;
    font-size: 1.5em;
    color:#fff;
    font-family: Verdana,Tahoma,arial;
    font-size: 11px;
}
/*div#ft {
    border-top: 2px solid black;
}
div#ft p {
    swidth: 500px;
    margin: 1em auto;
}
p#builtby {
    font-size: 0.8em;
    text-align: right;
    color: #666;
}*/
div#bd {
    /*position: relative;*/
}
div#gmap {
    width: 100%;
    height: 100%; /*400px;*/ /* If you change this don't forget to change the crosshair position to match */
}
div#crosshair {
    position: absolute;
    top: 50%;
    left: 50%;
    margin-left: -8px;
    display: block;
    height: 34px;
    width: 34px;
    background: url('./images/blue-circle.png');

    /*height: 23px;
    width: 23px;
    background: url('./images/crosshair.png');    */
    background-position: center center;
    background-repeat: no-repeat;
}
#map {
  width: 600px;
  height: 500px;
  margin: 2em auto;
}

#pic {
  width: 400px;
  height: 190px;
  padding: 5px;
}

#pic p {
  margin: 0;
  text-align: center;
  font: italic small Arial, sans-serif;
  float: left;
}

#pic img {
  display: block;
  width: 268px;
  height: 188px;
  float: left;
  padding-right: 5px;
}
</style>
<script type="text/javascript" src="./extjs4.7/ext-all.js"></script>

<script src="http://www.google.com/jsapi?key=AIzaSyCtiC-qe7eVo66mhdAMNosaIJ-z-tYVt2I" type="text/javascript"></script>
<!--script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=AIzaSyCtiC-qe7eVo66mhdAMNosaIJ-z-tYVt2I" type="text/javascript"></script-->
<script src="./scripts/ajax.js" type="text/javascript"></script>
<script type="text/javascript">
google.load('maps', '2'); // Load version 2 of the Maps API


function saveComplaint(){
	/*var name = document.getElementById('name').value;
	var mobile = document.getElementById('mobile').value;
	var address = document.getElementById('address').value;
	var landline = document.getElementById('phone').value;
	
	
	if(name==""){
		alert('Please enter the Name');
		document.getElementById('name').focus();
		return false;		
	}else if(mobile==""){
		alert('Please enter the Mobile Number');
		document.getElementById('mobile').focus();
		return false;		
	}else if(address==""){
		alert('Please enter the Address');
		document.getElementById('address').focus();
		return false;		
	}
	
	
	theUrl = "./includes/patrolajx.php";
	theData = "todo=Add_Complaint&name="+name+"&mobile="+mobile+"&address="+address+"&phone="+landline;
	ajaxCtrl(saved(),theUrl,theData); */
	
	Ext.onReady(function() {
		var compForm = Ext.create('Ext.form.Panel', {
			//url:'save-form.php',
			id:'compForm',
			frame:true,
			//title: 'Simple Form',
			labelSeparator:'',
			bodyStyle:'padding:5px 5px 0',
			//width: 350,
			fieldDefaults: {
				msgTarget: 'side',
				labelWidth: 75
			},
			defaultType: 'textfield',
			defaults: {
				anchor: '100%'
			},

			items: [{
				fieldLabel: 'Name',
				name: 'name',
				id: 'name',
				allowBlank:false,
				blankText:'Please enter the Name'
			},{
				fieldLabel: 'Mobile',
				name: 'mobile',
				id: 'mobile',
				allowBlank:false,
				blankText:'Please enter the Mobile No'
			},{
				fieldLabel: 'Landline',
				name: 'phone',
				id: 'phone'
			}, {
				fieldLabel: 'Address',
				name: 'address',
				xtype:'textarea',
				id: 'address',
				grow: true,
				growMax:80,
				allowBlank:false,
				blankText:'Please enter the Address'
			}],
			buttons: [{
				text:"Add Complaint",
				handler:function(){
					var formPanel = Ext.getCmp('compForm').getForm();
					if(formPanel.isValid()){
						formPanel.submit({
							clientValidation: true,
							url: 'includes/patrolajx.php',
							params: {
								todo: 'Add_Complaint', complaintid:0
							},
							success: function(form, action) {
							   Ext.Msg.alert('Success', action.result.msg);
							   compWin.destroy();
							   //Ext.getCmp("ComplaintsGrid").getStore().loadPage(1);
							   //complaintsStore.load({params:{start:0, limit:30}});
							},
							failure: function(form, action) {
								switch (action.failureType) {
									case Ext.form.action.Action.CLIENT_INVALID:
										Ext.Msg.alert('Failure', 'Form fields may not be submitted with invalid values');
										break;
									case Ext.form.action.Action.CONNECT_FAILURE:
										Ext.Msg.alert('Failure', 'Ajax communication failed');
										break;
									case Ext.form.action.Action.SERVER_INVALID:
									   Ext.Msg.alert('Failure', action.result.msg);
							   }
							}
						});
					}
				}
			},{
				text: 'Reset',
				hidden:false,
				handler: function() {
					Ext.getCmp('compForm').getForm().reset();
				}
			},{
				text: 'Close',
				handler: function() {
					compWin.destroy();
				}
			}]
		}).show();
		
	
		var compWin = Ext.create('Ext.Window', {
			title: "Save Complaint",
			width:300,
			height:250,
			plain: true,
			modal:true,
			closable:true,
			border: false,
			resizable:false,
			layout: {
		//        align: 'stretch',
				type: 'fit'
			},
			items: [compForm]/*,
			buttons: [{
				text: 'Close',
				handler: function() {
					compWin.destroy();
				}
			}]*/
		}).show();	
		Ext.getCmp('name').focus(true,1000);
		
		Ext.getCmp('address').setValue(document.getElementById('address_hid').value);
		//alert(document.getElementById('address_hid').value);
	
    });	
	
	
	
}

function saved(xmlHttp){
	alert(xmlHttp.responseText);	
}
function showComplaints(){
	theUrl = "./includes/patrolajx.php";
	theData = "todo=Get_complaints_List";
	ajaxCtrl(showList,theUrl,theData);	
}
function showList(){
	//alert(xmlHttp.responseText);
	//document.getElementById('complaintsList').innerHTML = xmlHttp.responseText;
	Ext.onReady(function() {

		Ext.define('complaintsData', {
			extend: 'Ext.data.Model',
			fields: [
				{name: 'complaintid',mapping: 'complaintid',type:'int'},
				{name: 'name',mapping: 'name', type: 'string'},
				{name: 'mobile',mapping: 'mobile',type:'int'},
				{name: 'phone',mapping: 'phone',type:'int'},
				{name: 'address',mapping: 'address', type: 'string'},
				{name: 'complaintdate',mapping: 'complaintdate', type: 'string'}
				],
			idCustomer: 'complaintid'
		});


		// create the Data Store
		var complaintsStore = Ext.create('Ext.data.JsonStore', {
			id: 'complaintsStore',
			pageSize: 30,
			model: 'complaintsData',
			remoteSort: false,
			proxy: {
				type: 'ajax',
				actionMethods: {
					read: 'POST'
				},
				url: './includes/patrolajx.php',
				extraParams: {
					todo : 'Get_complaints_List'
				},
				reader: {
					type: 'json',
					root: 'COMPLAINTS',
					totalProperty: 'totalCount'
				},
				// sends single sort as multi parameter
				simpleSortMode: true
			},
			sorters: [{
				property: 'complaintid',
				direction: 'DESC'
			}]
		});

		var complaintsCol	= [	Ext.create('Ext.grid.RowNumberer'),
			{text: "Complaint Id", dataIndex: 'complaintid',hidden:true, flex: 1, sortable: true},
			{ text: "Name", dataIndex: 'name', flex: 1, sortable: true},
			{ text: "Mobile", dataIndex: 'mobile', flex: 1, sortable: true},
			{ text: "Phone", dataIndex: 'phone', flex: 1, sortable: true},
			{ text: "Address", dataIndex: 'address', flex: 1, sortable: true},
			{ text: "Complaint Date", dataIndex: 'complaintdate', flex: 1, sortable: true}

		];	
		
		var ComplaintsGrid = Ext.create('Ext.grid.Panel', {
			columns: complaintsCol,
			border:false,
			collapsible: false,
			animCollapse: false,
			stripeRows: true,
			height: 500,
			width: 800,
			//title: 'Complaints',
			//renderTo: 'complaintsDiv',
			store:complaintsStore,
			dockedItems: [{
				xtype: 'pagingtoolbar',
				id:'ComplaintsGridPbar',
				store: complaintsStore,
				dock: 'bottom',
				pageSize: 30,
				displayInfo: true
			}],
			viewConfig: {
				stripeRows: true
			}
		});		
		complaintsStore.load({params:{start:0, limit:30}});
		
		var customerWin = Ext.create('Ext.Window', {
			title: "Complaints",
			width:850,
			height:550,
			plain: true,
			modal:true,
			closable:true,
			border: false,
			resizable:false,
			layout: {
		//        align: 'stretch',
				type: 'fit'
			},
			items: [ComplaintsGrid],
			buttons: [{
				text: 'Close',
				handler: function() {
					customerWin.destroy();
				}
			}]
		}).show();			
	
	});
	
}
function timezoneLoaded(obj) {
    var timezone = obj.timezoneId;
    if (!timezone) {
        return;
    }
    document.getElementById('timezone').innerHTML = timezone;
    document.getElementById('timezonep').style.display = 'none'; /*block*/
    // Find out what time it is there
    var s = document.createElement('script');
    s.src = "http://json-time.appspot.com/time.json?callback=timeLoaded&tz=" + timezone;
    s.type = 'text/javascript';
    document.getElementsByTagName('head')[0].appendChild(s);
}

function timeLoaded(obj) {
    if (obj.datetime) {
        document.getElementById('datetime').innerHTML = obj.datetime;
        document.getElementById('datetimep').style.display = 'none'; /*block*/
    }
}

function setPoint1(){
    var center = gmap.getCenter();
    document.getElementById("lat").innerHTML = center.lat();
    document.getElementById("lon").innerHTML = center.lng();

    document.getElementById("latlon1").innerHTML = center.lat() + ","+ center.lng();
    document.getElementById("latlon1_Hid").value = center.lat() + ","+ center.lng();
}


function setPoint2(){
    var center = gmap.getCenter();
    document.getElementById("lat").innerHTML = center.lat();
    document.getElementById("lon").innerHTML = center.lng();

    document.getElementById("latlon2").innerHTML = center.lat() + ","+ center.lng();
    document.getElementById("latlon2_Hid").value = center.lat() + ","+ center.lng();
}
function setPoint3(){
    var center = gmap.getCenter();
    document.getElementById("lat").innerHTML = center.lat();
    document.getElementById("lon").innerHTML = center.lng();

    document.getElementById("latlon3").innerHTML = center.lat() + ","+ center.lng();
    document.getElementById("latlon3_Hid").value = center.lat() + ","+ center.lng();
}
function setPoint4(){
    var center = gmap.getCenter();
    document.getElementById("lat").innerHTML = center.lat();
    document.getElementById("lon").innerHTML = center.lng();

    document.getElementById("latlon4").innerHTML = center.lat() + ","+ center.lng();
    document.getElementById("latlon4_Hid").value = center.lat() + ","+ center.lng();
}

function drawFencing(){
    //alert(document.getElementById("latlon1_Hid").value +'\n'+document.getElementById("latlon2_Hid").value +'\n'+document.getElementById("latlon3_Hid").value +'\n'+document.getElementById("latlon4_Hid").value);
    var val1Str = document.getElementById("latlon1_Hid").value.split(",");
    var val2Str = document.getElementById("latlon2_Hid").value.split(",");
    var val3Str = document.getElementById("latlon3_Hid").value.split(",");
    var val4Str = document.getElementById("latlon4_Hid").value.split(",");

    var lat1 = val1Str[0];
    var lon1 = val1Str[1];

    var lat2 = val2Str[0];
    var lon2 = val2Str[1];

    var lat3 = val3Str[0];
    var lon3 = val3Str[1];

    var lat4 = val4Str[0];
    var lon4 = val4Str[1];

    var pts = [];

    pts[0] = new GLatLng( parseFloat(lat1),parseFloat(lon1) );
    pts[1] = new GLatLng( parseFloat(lat2),parseFloat(lon2) );
    pts[2] = new GLatLng( parseFloat(lat3),parseFloat(lon3) );
    pts[3] = new GLatLng( parseFloat(lat4),parseFloat(lon4) );
    pts[4] = new GLatLng( parseFloat(lat1),parseFloat(lon1) );

    var poly = new GPolygon(pts,"#000000",1,1,"#00ffff",0.5,{clickable:false});

                  gmap.clearOverlays();
                  gmap.addOverlay(poly);
        /*
        var latOffset = 0.01;
        var lonOffset = 0.01;

        var lat =

        var polygon = new GPolygon([
            new GLatLng(lat, lon - lonOffset),
            new GLatLng(lat + latOffset, lon),
            new GLatLng(lat, lon + lonOffset),
            new GLatLng(lat - latOffset, lon),
            new GLatLng(lat, lon - lonOffset)
		], "#f33f00", 5, 1, "#ff0000", 0.2);
		  map.addOverlay(polygon);
        });*/

}

function updateLatLonFields(lat, lon) {
    //document.getElementById("latlon").innerHTML = lat + ', ' + lon;
    //document.getElementById("wkt").innerHTML = 'POINT('+lon+' '+lat +')';

    document.getElementById("lat").innerHTML = lat ;
    document.getElementById("lon").innerHTML = lon ;
}

function getOSMMapType() {
    // Usage: map.addMapType(getOSMMapType());
    var copyright = new GCopyrightCollection(
        '<a href="http://www.openstreetmap.org/">OpenStreetMap</a>'
    );
    copyright.addCopyright(
        new GCopyright(1, new GLatLngBounds(
            new GLatLng(-90, -180),
            new GLatLng(90, 180)
        ), 0, ' ')
    );
    var tileLayer = new GTileLayer(copyright, 1, 18, {
        tileUrlTemplate: 'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png',
        isPng: false
    });
    var mapType = new GMapType(
        [tileLayer], G_NORMAL_MAP.getProjection(), 'OSM'
    );
    return mapType;
}

function showMap() {
     var myOptions = {
        mapTypeControl: true,
        mapTypeControlOptions: {
            position: google.maps.ControlPosition.BOTTOM_CENTER
        },
        panControl: true,
        panControlOptions: {
            position: google.maps.ControlPosition.TOP_RIGHT
        },
        zoomControl: true,
        zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_CENTER
        },
        scaleControl: true,
        scaleControlOptions: {
            position: google.maps.ControlPosition.RIGHT_CENTER
        },
        streetViewControl: true,
        streetViewControlOptions: {
            position: google.maps.ControlPosition.RIGHT_CENTER
        }
     }
    window.gmap = new google.maps.Map2(document.getElementById('gmap'),myOptions);
    gmap.addControl(new google.maps.LargeMapControl());
    gmap.addControl(new google.maps.MapTypeControl());
    gmap.addMapType(getOSMMapType());
    gmap.enableContinuousZoom();
    gmap.enableScrollWheelZoom();

    var timer = null;

    google.maps.Event.addListener(gmap, "move", function() {
        var center = gmap.getCenter();
        updateLatLonFields(center.lat(), center.lng());

        // Wait a second, then figure out the timezone
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
        timer = setTimeout(function() {
            document.getElementById('timezonep').style.display = 'none';
            document.getElementById('datetimep').style.display = 'none';
            // Look up the timezone using geonames
            var s = document.createElement('script');
            s.type = 'text/javascript';
            s.src = "http://ws.geonames.org/timezoneJSON?lat=" + center.lat() + "&lng=" + center.lng() + "&callback=timezoneLoaded";
            document.getElementsByTagName("head")[0].appendChild(s);
        }, 1500);

    });
    google.maps.Event.addListener(gmap, "zoomend", function(oldZoom, newZoom) {
        document.getElementById("zoom").innerHTML = newZoom;
    });
    google.maps.Event.addDomListener(document.getElementById('crosshair'),
        'dblclick', function() {
            gmap.zoomIn();
        }
    );

    // Default view of the world
    gmap.setCenter(
        new google.maps.LatLng(13.049065452091314, 80.24205923080444),14 //43.834526782236814, -37.265625), 3
    );
    /*    var bounds = gmap.getBounds();
        var southWest = bounds.getSouthWest();
        var northEast = bounds.getNorthEast();
        var lngSpan = northEast.lng() - southWest.lng();
        var latSpan = northEast.lat() - southWest.lat();

	for (var i = 0; i < 10; i++) {
		var latlng = new GLatLng(southWest.lat() + latSpan * Math.random(),southWest.lng() + lngSpan * Math.random());
		gmap.addOverlay(new GMarker(latlng));
    }*/

    /* If we have a best-guess for the user's location based on their IP,
       show a "zoom to my location" link */
    if (google.loader.ClientLocation) {
        var link = document.createElement('a');
        link.onclick = function() {
            gmap.setCenter(
                new google.maps.LatLng(
                    google.loader.ClientLocation.latitude,
                    google.loader.ClientLocation.longitude
                ), 14
            );
            return false;
        }
        link.href = '#'
        link.appendChild(
            document.createTextNode('Zoom to my location (by IP)')
        );
        var form = document.getElementById('geocodeForm');
        var p = form.getElementsByTagName('p')[0];
        p.appendChild(link);
    }

    // Set up Geocoder
    window.geocoder = new google.maps.ClientGeocoder();

    // If query string was provided, geocode it
    var bits = window.location.href.split('?');
    if (bits[1]) {
        var location = decodeURI(bits[1]);
        document.getElementById('geocodeInput').value = location;
        geocode(location);
    }

    // Set up the form
    var geocodeForm = document.getElementById('geocodeForm');
    geocodeForm.onsubmit = function() {
        geocode(document.getElementById('geocodeInput').value);

        /*******
		 *
		 * generate random patrol vehicles nearby the searched place
		 *
		 ********/
	/*	var bounds = gmap.getBounds();
        var southWest = bounds.getSouthWest();
        var northEast = bounds.getNorthEast();
        var lngSpan = northEast.lng() - southWest.lng();
        var latSpan = northEast.lat() - southWest.lat();
		//alert(latSpan+'\n'+Math.random()+'\n'+latSpan * Math.random());

        // Create our "tiny" marker icon
        var blueIcon = new GIcon(G_DEFAULT_ICON);
        blueIcon.image = "./images/policecar.png";

		// Set up our GMarkerOptions object
		markerOptions = { icon:blueIcon };

		//for (var i = 0; i < 2; i++) {
			//if(i==0)gmap.clearOverlays();
			//alert(Math.random());
			//alert(document.getElementById("lat").innerHTML);
			//var tmplatary = document.getElementById("lat").innerHTML.split(".")
			//alert( tmplatary[0]+'\n'+tmplatary[1]+'\n'+document.getElementById("lat").innerText );

			//alert(parseFloat(0.0+tmplatary[1])+0.10);

			//var latlng = new GLatLng(southWest.lat() + latSpan * Math.random(),southWest.lng() + lngSpan * Math.random());
			//alert(southWest.lat()+'\n'+southWest.lat() + 0.30);

var center = gmap.getCenter();
        //updateLatLonFields(center.lat(), center.lng());

			var latlng = new GLatLng(center.lat(), center.lng() );
			var pmarker = new GMarker(latlng,markerOptions)
			gmap.addOverlay(pmarker);
			//getAddress(latlng);
			    /*pmarker.openInfoWindowHtml(
					'<b>orig latlng:</b>' + response.name + '<br/>' +
					'<b>latlng:</b>' + place.Point.coordinates[1] + "," + place.Point.coordinates[0] + '<br>' +
					'<b>Status Code:</b>' + response.Status.code + '<br>' +
					'<b>Status Request:</b>' + response.Status.request + '<br>' +
					'<b>Address:</b>' + place.address + '<br>' +
					'<b>Accuracy:</b>' + place.AddressDetails.Accuracy + '<br>' +
					'<b>Country code:</b> ' + place.AddressDetails.Country.CountryNameCode);
			    }*/
		//}
        return false;
    }
}

function getAddress(latlng) {
  if (latlng != null) {
    address = latlng;
    geocoder.getLocations(latlng, showAddress);
  }
}

function showAddress(response) {
  gmap.clearOverlays();
  if (!response || response.Status.code != 200) {
    return response.Status.code;
  } else {
    return response.Status.code;
  }
}

function showAddress1(response) {
  gmap.clearOverlays();
  if (!response || response.Status.code != 200) {
    alert("Status Code:" + response.Status.code);
  } else {
    place = response.Placemark[0];
    point = new GLatLng(place.Point.coordinates[1],place.Point.coordinates[0]);
    marker = new GMarker(point);
    map.addOverlay(marker);
    marker.openInfoWindowHtml(
        '<b>orig latlng:</b>' + response.name + '<br/>' +
        '<b>latlng:</b>' + place.Point.coordinates[1] + "," + place.Point.coordinates[0] + '<br>' +
        '<b>Status Code:</b>' + response.Status.code + '<br>' +
        '<b>Status Request:</b>' + response.Status.request + '<br>' +
        '<b>Address:</b>' + place.address + '<br>' +
        '<b>Accuracy:</b>' + place.AddressDetails.Accuracy + '<br>' +
        '<b>Country code:</b> ' + place.AddressDetails.Country.CountryNameCode);
  }
}

var accuracyToZoomLevel = [
    1,  // 0 - Unknown location
    5,  // 1 - Country
    6,  // 2 - Region (state, province, prefecture, etc.)
    8,  // 3 - Sub-region (county, municipality, etc.)
    11, // 4 - Town (city, village)
    13, // 5 - Post code (zip code)
    15, // 6 - Street
    16, // 7 - Intersection
    17, // 8 - Address
    17  // 9 - Premise
];

function geocodeComplete(result) {
    if (result.Status.code != 200) {
        alert('Could not geocode "' + result.name + '"');
        return;
    }
	gmap.clearOverlays();

    var placemark = result.Placemark[0]; // Only use first result
    var accuracy = placemark.AddressDetails.Accuracy;
    var zoomLevel = accuracyToZoomLevel[accuracy] || 1;
    var lon = placemark.Point.coordinates[0];
    var lat = placemark.Point.coordinates[1];
    gmap.setCenter(new google.maps.LatLng(lat, lon), zoomLevel);

       // Create our "tiny" marker icon
        var blueIcon = new GIcon(G_DEFAULT_ICON);
        blueIcon.image = "./images/policecar.png";

		// Set up our GMarkerOptions object
		markerOptions = { icon:blueIcon };

		var center = gmap.getCenter();
        //updateLatLonFields(center.lat(), center.lng());

		var latlng = new GLatLng(center.lat(), center.lng() );
		var pmarker = new GMarker(latlng,markerOptions)
		gmap.addOverlay(pmarker);

		var infoStr ='<div id="complaintsDiv">'+
				'<table width="100%" cellpadding=="0" cellspacing="0">'+
					'<tr>'+
						'<td style="color:#fff;text-align:center;font-family:verdana,arial,tahoma;font-size:11pt;">'+placemark.address+'</td>'+
					'</tr>'+
				'</table>'+		
			'</div>';
		// var infoWindow = new google.maps.Map2;
		// GEvent.addListener(pmarker, "click", function() {
			
			// if (!infoWindow) {
				   // infoWindow = new gMap.InfoWindow();
				// }
			// infoWindow.setContent(infoStr);
			// infoWindow.open(gmap, pmarker);
			// });
		
		var patrolAddress = "<b>Patrol Location: </b>"+placemark.address;
		var patrolDetails = "<b>Patrol Person:</b> Mr. Palani<br/>"+"<b>MIC No:</b> 456<br/>"+"<b>Mobile No:</b> 9000000000";
var htmlNode = document.createElement('span');
    htmlNode.innerHTML = patrolAddress+"<br/>"+patrolDetails;
//		pmarker.openInfoWindow(document.createTextNode(patrolAddress+"<br/>"+patrolDetails));
		pmarker.openInfoWindow(htmlNode);

		
		GEvent.addListener(pmarker, "click", function() {
           pmarker.openInfoWindow(htmlNode);
        });
		if(placemark.address!=undefined){
			document.getElementById('address_hid').value = placemark.address;
		}


}

function geocode(location) {
    geocoder.getLocations(location, geocodeComplete);
}

google.setOnLoadCallback(showMap);
</script>
</head>
<body>
    <div id="hd">

        <!--div id="shd1" style="float:right;text-align: right;padding-right: 20px;">
            <p>
                <input type="button" name="Btnpos1" id="Btnpos1" Value="Set Point 1" onclick="setPoint1()"/>

            </p>
            <p>
                <input type="button" name="Btnpos2" id="Btnpos2" Value="Set Point 2" onclick="setPoint2()"/>
            </p>
            <p>
                <input type="button" name="Btnpos3" id="Btnpos3" Value="Set Point 3" onclick="setPoint3()"/>
            </p>
            <p>
                <input type="button" name="Btnpos4" id="Btnpos4" Value="Set Point 4" onclick="setPoint4()"/>
            </p>
            <p>
                <input type="button" name="BtndrawFence" id="BtndrawFence" Value="Draw Fencing Area" onclick="drawFencing()"/>
            </p>
        </div-->

        <table width="100%" cellpadding=="0" cellspacing="0">
            <tr>
                <td valign="top">
                    <h1>Locate a Patrol Vechicle</h1>
                    <!--p>Mark four points to draw the Fencing area</p-->
                    <form action="http://maps.google.com/maps" id="geocodeForm">
                        <p>
                            <label for="geocodeInput">Location: </label>
                            <input type="text" name="q" id="geocodeInput" value="52, Giri Road, T.nagar, chennai">
                            <!-- "Accessible" version of Google Maps: -->

                            <input type="hidden" name="output" value="html">
                            <input type="submit" id="ButtonFind" value="Find">
                        </p>

                    </form>

                    <!--<p><strong>Latitude, Longitude:</strong> <span id="latlon"></span></p>-->
                    <p style="color:#FF0000;">Latitude &#160;&#160;: <span id="lat"></span></p>
                    <p style="color:#FF0000;">Longitude: <span id="lon"></span></p>
                    <p style="color:#FF0000;display: none">Position1:<span id="latlon1"></span><input type="hidden" id="latlon1_Hid"/></p>
                    <p style="color:#FF0000;display: none">Position2:<span id="latlon2"></span><input type="hidden" id="latlon2_Hid"/></p>
                    <p style="color:#FF0000;display: none">Position3:<span id="latlon3"></span><input type="hidden" id="latlon3_Hid"/></p>
                    <p style="color:#FF0000;display: none">Position4:<span id="latlon4"></span><input type="hidden" id="latlon4_Hid"/></p>

                    <p style="display: none;"><strong>WKT:</strong> <span id="wkt"></span></p>
                    <p style="display: none;"><strong>Google Maps zoom level:</strong> <span id="zoom"></span></p>
                    <p style="display: none;color:#FF0000;" id="timezonep"><strong>Timezone:</strong> <span id="timezone"></span></p>
                    <p id="datetimep" style="display: none;"><strong>Local time:</strong> <span id="datetime"></span></p>
					<p><br/><br/><input type="hidden" id="address_hid"/><input type="button" name="BtnSave" id="BtnSave" Value="Save Complaint" onclick="saveComplaint()"/>&#160;&#160;&#160;&#160;<input type="button" name="BtnShow" id="BtnShow" Value="Show Complaints" onclick="showComplaints()"/></p>

                </td>
                <td valign="top">
					<!--form id="frmcomplaint" name="frmcomplaint">
						<table width="80%" cellpadding=="0" cellspacing="0">
							<tr>
								<td colspan="2" class="contactInfoHeading">Complaints & Information</td>
							</tr>
							<tr>
								<td class="contactInfo">Name</td>
								<td><input type="text" name="name" id="name" Value=""/></td>
							</tr>
							<tr>
								<td class="contactInfo">Mobile</td>
								<td><input type="text" name="mobile" id="mobile" Value=""/></td>
							</tr>
							<tr>
								<td class="contactInfo">Landline No</td>
								<td><input type="text" name="phone" id="phone" Value=""/></td>
							</tr>
							<tr>
								<td class="contactInfo">Address</td>
								<td valign="top"><textarea id="address" name="address" rows="3" cols="50"></textarea></td>
							</tr>
							<tr>
								<td><input type="button" name="BtnSave" id="BtnSave" Value="Save Complaint" onclick="saveComplaint()"/></td>
								<td>
								<input type="reset" name="BtnReset" id="BtnReset" Value="Reset" onclick="document.getElementById('frmcomplaint').reset()"/>
								&#160;&#160;&#160;&#160;<input type="button" name="BtnShow" id="BtnShow" Value="Show Complaints" onclick="showComplaints()"/>
								</td>
							</tr>
						</table>
					</form-->
                </td>
            </tr>

        </table>
    </div>
	
	<!--div id="complaintsDiv">
		<table width="100%" cellpadding=="0" cellspacing="0">
			<tr>
				<td colspan="2" height="20" bgcolor="#000000" style="color:#fff;text-align:center;font-family:verdana,arial,tahoma;font-size:11pt;">Complaints & Information</td>
			</tr>
			<tr>
				<td colspan="2" valign="top">
					<div id="complaintsList" sstyle="overflow:scroll;text-align: left;width:800px;background:#a1bcdf;color:#000;font-family: Calibri,verdana,tahoma,arial;font-size: 10px;">
					</div>
				</td>
			</tr>	
		</table>		
	</div-->

    <!--<div id="logo" style="position: absolute;left:0px;bottom: 0px">
        <img src="./images/loginlogo.png"/>
    </div>-->

    <div id="bd">
        <div id="gmap"></div>
        <div id="crosshair"></div>
    </div>

    <!--<div id="ft">
        <p><strong>Latitude, Longitude:</strong> <span id="latlon"></span></p>
        <p><strong>WKT:</strong> <span id="wkt"></span></p>
        <p><strong>Google Maps zoom level:</strong> <span id="zoom"></span></p>
        <p id="timezonep" style="display: none"><strong>Timezone:</strong> <span id="timezone"></span></p>
        <p id="datetimep" style="display: none"><strong>Local time:</strong> <span id="datetime"></span></p>
    </div>-->

</body>
</html>
