<?php
session_start();
include_once("../config/dbconn.php");

$todo = $_POST['todo'];

if($todo == "Get_Complaints_List"){
	$getQry = mysql_query("SELECT * FROM complaints ORDER BY complaintid DESC");
    $getCnt = mysql_num_rows($getQry);

    while($getRes = mysql_fetch_array($getQry)){
        $complaintid   	= $getRes['complaintid'];
		$name			= $getRes['name'];

		$myData[]	= array(
			'complaintid'	=> $complaintid,
			'name'	=> $name
		);
    }


	$myData = array('COMPLAINTS' => $myData, 'totalCount' => $getCnt);
	header('Content-Type: application/x-json');
    echo json_encode($myData);
}

if($todo == "Get_Device_List"){
	$getQry = mysql_query("SELECT * FROM gpsdata GROUP BY deviceid");
    $getCnt = mysql_num_rows($getQry);

    while($getRes = mysql_fetch_array($getQry)){
        $deviceid   	= $getRes['deviceid'];
		$devicename		= $getRes['deviceid'];

		$myData[]	= array(
			'deviceid'		=> $deviceid,
			'devicename'	=> $devicename
		);
    }


	$myData = array('DEVICES' => $myData, 'totalCount' => $getCnt);
	header('Content-Type: application/x-json');
    echo json_encode($myData);
}

if($todo == "Get_Device_Date_List"){
	$deviceid = $_POST['deviceid'];
	$getQry = mysql_query("SELECT * FROM gpsdata WHERE deviceid='".$deviceid."' ORDER BY posdatetime ASC");
    $getCnt = mysql_num_rows($getQry);

    while($getRes = mysql_fetch_array($getQry)){
        $gpsid   		= $getRes['gpsid'];
		$posdatetime	= $getRes['posdatetime'];

		$myData[]	= array(
			'gpsid'	=> $gpsid,
			'date'	=> date("d-m-Y H:i:s",strtotime($posdatetime))
		);
    }


	$myData = array('DATES' => $myData, 'totalCount' => $getCnt);
	header('Content-Type: application/x-json');
    echo json_encode($myData);
}

?>