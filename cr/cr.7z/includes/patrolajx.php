<?
#partolajx.php
session_start();
include_once("../config/dbconn.php");
include_once("./functions.php");

error_reporting(E_ALL);
ini_set('display_errors','On');

//$userid = $_SESSION['userid'];

$todo = $_POST['todo'];

if($todo == "Add_Complaint"){
	$name		= $_POST['name'];
	$phone		= $_POST['phone'];
	$mobile		= $_POST['mobile'];
	$address	= $_POST['address'];

	$chkQry	= mysql_query("SELECT * FROM complaints WHERE name='".$name."' AND mobile='".$mobile."'");
	$chkCnt	= mysql_num_rows($chkQry);
	if($chkCnt == 0){
		// $customerQry = "INSERT INTO complaints(name, phone, mobile, address,complaintdate,addedby,addedon)
						// VALUES('".$name."', '".$phone."', '".$mobile."', '".$address."',now(), '".$_SESSION['userid']."', '". date("Y-m-d H:i:s")."')";
		$customerQry = "INSERT INTO complaints(name, phone, mobile, address,complaintdate,addedby,addedon)
						VALUES('".$name."', '".$phone."', '".$mobile."', '".$address."',now(), 1,'". date("Y-m-d H:i:s")."')";
		$customerRes = mysql_query($customerQry);
		if($customerRes){
				echo "{ success: true,msg:'Complaint from <b>$name</b> Saved Successfully.'}";
		}
		else
			echo "{ success: false,msg:'Error while saving new Complaint'}";
	}else{
		echo "{ success: false,msg:'A Complaint with Same name and Mobile No already Exists.'}";
	}
}
if($todo == "Get_complaints_List"){
	// // $start	= $_POST['start'];
	// // $limit	= $_POST['limit'];

	// $totQry	= mysql_query("SELECT * FROM complaints ORDER BY complaintid DESC");
	// $totCnt	= mysql_num_rows($totQry);

	// if($totCnt == 0){
		// $myData[] = array(
			// 'complaintid'  	 => 0,
			// 'name'   => "<span class='tableTextM'>No complaints Found</span>"
		// );
	// }else{
		// $vehicleQry = mysql_query("SELECT *,DATE_FORMAT(complaintdate,'%d-%m-%Y %H:%m') complaintdate FROM complaints ORDER BY complaintid DESC"); //LIMIT $start , $limit
		// $outStr  = '<table width="100%" cellpadding=="0" cellspacing="0">';
		// $outStr .= '	<tr>';
		// $outStr .= '		<td>Name</td>';
		// $outStr .= '		<td>Mobile</td>';
		// $outStr .= '		<td>Landline</td>';
		// $outStr .= '		<td>Address</td>';
		// $outStr .= '	</tr>';

		// while($complaintRes = mysql_fetch_array($vehicleQry)){
			// $outStr .= '	<tr>';
			// //$outStr .= '		<td>'.$complaintRes['complaintid'].'</td>';
			// $outStr .= '		<td>'.$complaintRes['name'].'</td>';
			// $outStr .= '		<td>'.$complaintRes['mobile'].'</td>';
			// $outStr .= '		<td>'.$complaintRes['phone'].'</td>';
			// $outStr .= '		<td>'.$complaintRes['address'].'</td>';
			// //$outStr .= '		<td>'.$complaintRes['complaintdate'].'</td>';
			// $outStr .= '	</tr>';
		// }
	// }
	
	// $outStr .= '</table>';						
	
	// echo $outStr;
	
	$start	= $_POST['start'];
	$limit	= $_POST['limit'];

	$totQry	= mysql_query("SELECT * FROM complaints ORDER BY complaintid DESC");
	$totCnt	= mysql_num_rows($totQry);

	if($totCnt == 0){
		$myData[] = array(
			'complaintid'  	 => 0,
			'name'   => "<span class='tableTextM'>No complaints Found</span>"
		);
	}else{
		$vehicleQry = mysql_query("SELECT *,DATE_FORMAT(complaintdate,'%d-%m-%Y %H:%m') complaintdate FROM complaints ORDER BY complaintid DESC LIMIT $start , $limit");
		while($complaintRes = mysql_fetch_array($vehicleQry)){
			$myData[] = array(
				'complaintid'  		=> $complaintRes['complaintid'],
				'name'  			=> $complaintRes['name'],
				'mobile'			=> $complaintRes['mobile'],
				'phone'  			=> $complaintRes['phone'],
				'address'   		=> $complaintRes['address'],
				'complaintdate'		=> $complaintRes['complaintdate']

				/*'action'			=> "<img src='./images/device.png' onclick='getDevices(\'".$complaintRes['customerid']."\')'/>"*/
			);
		}
	}

    $myData = array('COMPLAINTS' => $myData, 'totalCount' => $totCnt);
	header('Content-Type: application/x-json');
    echo json_encode($myData);	
	
}

?>
