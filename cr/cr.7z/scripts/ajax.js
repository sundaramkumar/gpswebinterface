/*
ajax.js
*/
function XmlHttp() {}
	XmlHttp.create = function () {
	try {
		if (window.XMLHttpRequest) {
			var req = new XMLHttpRequest();
			// some older versions of Moz did not support the readyState property
				// and the onreadystate event so we patch it!
			if (req.readyState == null) {
			    req.readyState = 1;
			    req.addEventListener("load", function () {
					req.readyState = 4;
					if (typeof req.onreadystatechange == "function")
					    req.onreadystatechange();
				    }, false);
				}
			return req;
		}
		if (window.ActiveXObject) {
			return new ActiveXObject(getControlPrefix() + ".XmlHttp");
		}
	}
	catch (ex) {}
	// fell through
	throw new Error("Your browser does not support XmlHttp objects");
};

function getControlPrefix() {
       if (getControlPrefix.prefix)
	  return getControlPrefix.prefix;
       var prefixes = ["MSXML2", "Microsoft", "MSXML", "MSXML3"];
       var o, o2;
       for (var i = 0; i < prefixes.length; i++) {
	  try {
	     o = new ActiveXObject(prefixes[i] + ".XmlHttp");
	     o2 = new ActiveXObject(prefixes[i] + ".XmlDom");
	     return getControlPrefix.prefix = prefixes[i];
	  }
	  catch (ex) {};
       }
       throw new Error("Could not find an installed XML parser");
}
var callInProgress = false;
var xmlHttp;
function ajaxCtrl(fnfragment,theUrl,theData){
	//myRand = parseInt(Math.random()*999999999999999);
	var bAsync = true;

	this.xmlHttp = XmlHttp.create();

	if(theUrl)
		var url = theUrl; //+"?rand="+myRand;
	else{
		alert('Target URL is Empty');
		return false;
	}
	try {
		xmlHttp.open("POST", url,bAsync);
	   	callInProgress = true;
	}catch(e){
	   	callInProgress = false;
	   	return false;
	}
	if (bAsync) {
		xmlHttp.onreadystatechange= function(){
			//alert(xmlHttp.readyState);
			switch (xmlHttp.readyState) {
				case 4:
					callInProgress = false;					
					if(fnfragment){						
						fnfragment(xmlHttp);

						// Clean up so IE doesn't leak memory
						//delete xmlHttp.onreadystatechange;
						//xmlHttp = null;

					}
					break;
			}
			/* if(xmlHttp.readyState == 4){
				callInProgress = false;
				if(fnfragment){
					fnfragment();

					// Clean up so IE doesn't leak memory
					//delete xmlHttp.onreadystatechange;
					//xmlHttp = null;

				}
			} */
		}
	}

	xmlHttp.setRequestHeader("Content-type","application/x-www-form-urlencoded;charset=UTF-8");

	if(theData)
		theKeyValPair = theData;
	else
		theKeyValPair = "";

	try {
		callInProgress = true;
		xmlHttp.send(theKeyValPair);
	}
	catch (e) {
		callInProgress = false;
		alert("Could not contact Server at this Time. Please Try again Later");
		return false;
	}

	if (!bAsync) {
	    done();
	}
}

